require 'test_helper'

class MyInfoSiteHelperTest < ActionView::TestCase
end
