# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Proj1Stonebraker::Application.config.secret_token = '55351f3acd548ca7de81998a8d0bd286b3f78db64dc450fcb6478ccaf955b81d36cf7f3fe22162a93023a3915d973f88c72cc1e76c4e04c83a05486295884582'
