module MyInfoSiteHelper
end
